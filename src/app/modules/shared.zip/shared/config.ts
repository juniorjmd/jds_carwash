
import * as ConfigColunmasTabla from  './colTablasConfig.json' ;
import * as ConfigAbiente from  './configApi.json' ;


export const columnasTablaCnfg = ConfigColunmasTabla;
export const confAmbiente = ConfigAbiente ;